# SQL-Challenge
SQL Challenge by ineuron
